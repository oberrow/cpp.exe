#ifindef Pins_Arduino_h
#define Pins_Arduino_h

static const uint8_t A1 = 2;
static const uint8_t A2 = 4;
static const uint8_t A3 = 3;
static const uint8_t 1 = 6;
static const uint8_t 2 = 5;
